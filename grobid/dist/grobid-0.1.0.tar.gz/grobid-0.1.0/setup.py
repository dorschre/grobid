# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['grobid', 'grobid.api', 'grobid.api.pdf', 'grobid.models']

package_data = \
{'': ['*']}

install_requires = \
['attrs>=23.2.0,<24.0.0',
 'beautifulsoup4>=4.12.3,<5.0.0',
 'httpx>=0.27.0,<0.28.0',
 'lxml>=5.1.0,<6.0.0',
 'python-dateutil>=2.8.2,<3.0.0']

setup_kwargs = {
    'name': 'grobid',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Rene Dorsch',
    'author_email': 'renedorsch@yahoo.de',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
